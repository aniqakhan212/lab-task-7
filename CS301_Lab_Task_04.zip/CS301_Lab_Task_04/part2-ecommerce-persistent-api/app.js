// Router: /auth  /products  /cart  /reviews  /orders
const http = require('node:http');
const path = require('node:path');
const { HttpError, send } = require('./utils');
const { createDb } = require('./db');

const routes = {
  auth:     require('./modules/user.js'),
  products: require('./modules/product.js'),
  cart:     require('./modules/cart.js'),
  reviews:  require('./modules/review.js'),
  orders:   require('./modules/order.js')
};

// options.dataDir    folder for the JSON files (default ./data or $DATA_DIR)
// options.adminEmail the email that becomes admin when it signs up (or $ADMIN_EMAIL)
function createApp(options = {}) {
  const dataDir = options.dataDir || process.env.DATA_DIR || path.join(__dirname, 'data');
  const adminEmail = String(options.adminEmail ?? process.env.ADMIN_EMAIL ?? '').trim().toLowerCase();
  const ctx = { db: createDb(dataDir), adminEmail };

  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const parts = url.pathname.split('/').filter(Boolean);
      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { status: 'ok' });

      const module = routes[parts[0]];
      if (!module) throw new HttpError(404, 'Route not found');
      await module.handle(ctx, req, res, parts.slice(1), url);
    } catch (error) {
      if (res.headersSent) { res.destroy(error); return; }
      if (!(error instanceof HttpError)) console.error('[unexpected]', error);
      send(res, error instanceof HttpError ? error.status : 500,
        { error: error instanceof HttpError ? error.message : 'Internal server error' });
    }
  });
}

module.exports = { createApp };
