// Auth module:  POST /auth/signup   POST /auth/login   POST /auth/logout   GET /auth/me
const { HttpError, send, noContent, readBody, nextId, rules, validate } = require('../utils');
const auth = require('../auth');

async function signup(ctx, req, res) {
  const data = validate(await readBody(req), { name: rules.text, email: rules.email, password: rules.password });
  const passwordHash = await auth.hashPassword(data.password);
  const user = await ctx.db.users.edit((users) => {
    if (users.some((u) => u.email === data.email)) throw new HttpError(409, 'That email is already registered');
    const created = {
      id: nextId(users),
      name: data.name,
      email: data.email,
      role: data.email === ctx.adminEmail ? 'admin' : 'customer',
      passwordHash,
      createdAt: new Date().toISOString()
    };
    users.push(created);
    return { changed: true, value: created };
  });
  const token = await auth.createSession(ctx, user.id);
  send(res, 201, { user: auth.publicUser(user), token });
}

async function login(ctx, req, res) {
  const data = validate(await readBody(req), { email: rules.email, password: rules.password });
  const user = (await ctx.db.users.list()).find((u) => u.email === data.email);
  if (!user || !(await auth.checkPassword(data.password, user.passwordHash))) {
    throw new HttpError(401, 'Wrong email or password');
  }
  const token = await auth.createSession(ctx, user.id);
  send(res, 200, { user: auth.publicUser(user), token });
}

async function logout(ctx, req, res) {
  await auth.requireUser(ctx, req);
  await auth.destroySession(ctx, req);
  noContent(res);
}

async function me(ctx, req, res) {
  send(res, 200, auth.publicUser(await auth.requireUser(ctx, req)));
}

async function handle(ctx, req, res, parts) {
  const [action] = parts;
  if (parts.length !== 1) throw new HttpError(404, 'Route not found');
  if (action === 'signup' && req.method === 'POST') return signup(ctx, req, res);
  if (action === 'login' && req.method === 'POST') return login(ctx, req, res);
  if (action === 'logout' && req.method === 'POST') return logout(ctx, req, res);
  if (action === 'me' && req.method === 'GET') return me(ctx, req, res);
  if (['signup', 'login', 'logout', 'me'].includes(action)) throw new HttpError(405, 'Method not allowed');
  throw new HttpError(404, 'Route not found');
}

module.exports = { handle };
