// Review module.
//   GET /reviews, GET /reviews/:id   public (newest first; filter ?stars=5)
//   POST /reviews                    anyone; send "name" if not logged in
//   PATCH/PUT /reviews/:id           the review's author (or admin)
//   DELETE /reviews/:id              the review's author (or admin)
const { HttpError, send, noContent, readBody, parseId, nextId, rules, validate } = require('../utils');
const auth = require('../auth');

const fields = { name: rules.text, stars: rules.stars, text: rules.text };

async function getAll(ctx, req, res, url) {
  let items = [...(await ctx.db.reviews.list())].reverse(); // newest first
  const stars = url.searchParams.get('stars');
  if (stars) items = items.filter((r) => String(r.stars) === stars);
  send(res, 200, items);
}

async function getOne(ctx, req, res, id) {
  const review = (await ctx.db.reviews.list()).find((r) => r.id === id);
  if (!review) throw new HttpError(404, 'Review not found');
  send(res, 200, review);
}

async function create(ctx, req, res) {
  const user = await auth.currentUser(ctx, req);
  const body = await readBody(req);
  if (user && body && typeof body === 'object' && !Array.isArray(body) && body.name === undefined) {
    body.name = user.name; // logged-in users don't have to type a name
  }
  const data = validate(body, fields);
  const review = await ctx.db.reviews.edit((reviews) => {
    const created = { id: nextId(reviews), userId: user ? user.id : null, ...data, createdAt: new Date().toISOString() };
    reviews.push(created);
    return { changed: true, value: created };
  });
  send(res, 201, review);
}

// Only the author or an admin may change/delete a review.
function allowed(user, review) {
  if (user.role !== 'admin' && review.userId !== user.id) {
    throw new HttpError(403, 'You can only change your own reviews');
  }
}

async function update(ctx, req, res, id) {
  const user = await auth.requireUser(ctx, req);
  const data = validate(await readBody(req), { stars: rules.stars, text: rules.text }, req.method === 'PATCH');
  const review = await ctx.db.reviews.edit((reviews) => {
    const found = reviews.find((r) => r.id === id);
    if (!found) throw new HttpError(404, 'Review not found');
    allowed(user, found);
    Object.assign(found, data);
    return { changed: true, value: { ...found } };
  });
  send(res, 200, review);
}

async function remove(ctx, req, res, id) {
  const user = await auth.requireUser(ctx, req);
  await ctx.db.reviews.edit((reviews) => {
    const index = reviews.findIndex((r) => r.id === id);
    if (index < 0) throw new HttpError(404, 'Review not found');
    allowed(user, reviews[index]);
    reviews.splice(index, 1);
    return { changed: true, value: null };
  });
  noContent(res);
}

async function handle(ctx, req, res, parts, url) {
  if (parts.length > 1) throw new HttpError(404, 'Route not found');
  if (parts.length === 0) {
    if (req.method === 'GET') return getAll(ctx, req, res, url);
    if (req.method === 'POST') return create(ctx, req, res);
  } else {
    const id = parseId(parts[0]);
    if (req.method === 'GET') return getOne(ctx, req, res, id);
    if (req.method === 'PUT' || req.method === 'PATCH') return update(ctx, req, res, id);
    if (req.method === 'DELETE') return remove(ctx, req, res, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
