// Student module - CRUD
const db = require('../db');
const { HttpError, send, readBody, rules, validate, filterBy } = require('../utils');

const store = db.students;
const fields = { name: rules.text, department: rules.text };

const findIndex = (id) => {
  const index = store.items.findIndex((s) => s.id === id);
  if (index < 0) throw new HttpError(404, 'Student not found');
  return index;
};

// CREATE
async function create(req, res) {
  const student = { id: store.nextId++, ...validate(await readBody(req), fields) };
  store.items.push(student);
  send(res, 201, student);
}

// READ (all, with optional ?department=CS filter)
function getAll(req, res, url) {
  send(res, 200, filterBy(store.items, url, ['name', 'department']));
}

// READ (one)
function getOne(req, res, id) {
  send(res, 200, store.items[findIndex(id)]);
}

// UPDATE (PUT = all fields, PATCH = some fields)
async function update(req, res, id) {
  const index = findIndex(id);
  const data = validate(await readBody(req), fields, req.method === 'PATCH');
  store.items[index] = { ...store.items[index], ...data };
  send(res, 200, store.items[index]);
}

// DELETE (also removes this student's attendance and marks)
function remove(req, res, id) {
  store.items.splice(findIndex(id), 1);
  db.attendance.items = db.attendance.items.filter((a) => a.studentId !== id);
  db.marks.items = db.marks.items.filter((m) => m.studentId !== id);
  res.writeHead(204);
  res.end();
}

async function handle(req, res, id, url) {
  if (id === null) {
    if (req.method === 'GET') return getAll(req, res, url);
    if (req.method === 'POST') return create(req, res);
  } else {
    if (req.method === 'GET') return getOne(req, res, id);
    if (req.method === 'PUT' || req.method === 'PATCH') return update(req, res, id);
    if (req.method === 'DELETE') return remove(req, res, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
