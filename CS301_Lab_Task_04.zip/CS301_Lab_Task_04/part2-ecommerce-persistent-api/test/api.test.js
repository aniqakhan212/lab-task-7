// Integration tests (Node built-in test runner):  npm test
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createApp } = require('../app.js');

let server, base, dir;
const start = async () => {
  server = createApp({ dataDir: dir, adminEmail: 'admin@shop.com' });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
};
const stop = () => new Promise((r) => server.close(r));
before(async () => { dir = await fs.mkdtemp(path.join(os.tmpdir(), 'shop-')); await start(); });
after(async () => { await stop(); await fs.rm(dir, { recursive: true, force: true }); });

async function call(method, p, body, token) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(base + p, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
}

let ali, admin;
const shippingInfo = { name: 'Ali', address: '1 Main St', city: 'Islamabad', phone: '0300 1234567' };

test('health + seeded products', async () => {
  assert.equal((await call('GET', '/health')).status, 200);
  const r = await call('GET', '/products');
  assert.equal(r.body.length, 8);
  assert.equal((await call('GET', '/products?tag=audio')).body.length, 2);
  assert.equal((await call('GET', '/products/3')).body.name, 'Backpack');
  assert.equal((await call('GET', '/products/99')).status, 404);
});

test('signup, duplicate email, login, me, bad password', async () => {
  const s = await call('POST', '/auth/signup', { name: 'Ali', email: 'Ali@Test.com', password: 'secret1' });
  assert.equal(s.status, 201);
  assert.equal(s.body.user.passwordHash, undefined);
  assert.equal(s.body.user.role, 'customer');
  assert.equal((await call('POST', '/auth/signup', { name: 'X', email: 'ali@test.com', password: 'secret1' })).status, 409);
  assert.equal((await call('POST', '/auth/signup', { name: 'X', email: 'bad', password: 'secret1' })).status, 400);
  assert.equal((await call('POST', '/auth/login', { email: 'ali@test.com', password: 'nope123' })).status, 401);
  const l = await call('POST', '/auth/login', { email: 'ali@test.com', password: 'secret1' });
  ali = l.body.token;
  assert.equal((await call('GET', '/auth/me', undefined, ali)).body.email, 'ali@test.com');
  assert.equal((await call('GET', '/auth/me')).status, 401);
  admin = (await call('POST', '/auth/signup', { name: 'Boss', email: 'admin@shop.com', password: 'secret1' })).body.token;
  assert.equal((await call('GET', '/auth/me', undefined, admin)).body.role, 'admin');
});

test('cart: add, change, remove, auth required', async () => {
  assert.equal((await call('GET', '/cart')).status, 401);
  await call('POST', '/cart', { productId: 1, qty: 2 }, ali);
  const added = await call('POST', '/cart', { productId: 6 }, ali);
  assert.equal(added.status, 201);
  assert.equal(added.body.total, 132.48); // 2*59.99 + 12.5
  assert.equal((await call('POST', '/cart', { productId: 99 }, ali)).status, 404);
  assert.equal((await call('PATCH', '/cart/6', { qty: 3 }, ali)).body.total, 157.48);
  assert.equal((await call('DELETE', '/cart/6', undefined, ali)).status, 204);
  assert.equal((await call('DELETE', '/cart/6', undefined, ali)).status, 404);
  assert.equal((await call('GET', '/cart', undefined, ali)).body.items.length, 1);
});

test('orders: checkout, empty cart, privacy, cancel', async () => {
  assert.equal((await call('POST', '/orders', { shipping: { name: 'x' } }, ali)).status, 400);
  const o = await call('POST', '/orders', { shipping: shippingInfo, payment: 'cod' }, ali);
  assert.equal(o.status, 201);
  assert.equal(o.body.orderNo, 'ORD-000001');
  assert.equal(o.body.total, 119.98);
  assert.equal((await call('GET', '/cart', undefined, ali)).body.items.length, 0);
  assert.equal((await call('POST', '/orders', { shipping: shippingInfo }, ali)).status, 400); // empty cart
  assert.equal((await call('GET', '/orders', undefined, ali)).body.length, 1);
  const other = (await call('POST', '/auth/signup', { name: 'Zed', email: 'zed@test.com', password: 'secret1' })).body.token;
  assert.equal((await call('GET', '/orders/1', undefined, other)).status, 404);
  assert.equal((await call('PATCH', '/orders/1', { status: 'shipped' }, ali)).status, 403);
  assert.equal((await call('PATCH', '/orders/1', { status: 'shipped' }, admin)).body.status, 'shipped');
  assert.equal((await call('PATCH', '/orders/1', { status: 'cancelled' }, ali)).status, 409);
});

test('reviews: public read, anonymous post, own-only delete', async () => {
  assert.equal((await call('GET', '/reviews')).body.length, 2);
  const anon = await call('POST', '/reviews', { name: 'Guest', stars: 3, text: 'ok' });
  assert.equal(anon.status, 201);
  const mine = await call('POST', '/reviews', { stars: 5, text: 'great' }, ali);
  assert.equal(mine.body.name, 'Ali');
  assert.equal((await call('POST', '/reviews', { stars: 9, text: 'x', name: 'y' })).status, 400);
  assert.equal((await call('GET', '/reviews')).body[0].id, mine.body.id); // newest first
  const zed = (await call('POST', '/auth/login', { email: 'zed@test.com', password: 'secret1' })).body.token;
  assert.equal((await call('DELETE', `/reviews/${mine.body.id}`, undefined, zed)).status, 403);
  assert.equal((await call('PATCH', `/reviews/${mine.body.id}`, { stars: 4 }, ali)).body.stars, 4);
  assert.equal((await call('DELETE', `/reviews/${mine.body.id}`, undefined, ali)).status, 204);
});

test('products: admin-only CRUD, cart cleanup', async () => {
  const item = { name: 'Notebook', price: 4.5, icon: '📓', tag: 'Office', rating: 4 };
  assert.equal((await call('POST', '/products', item)).status, 401);
  assert.equal((await call('POST', '/products', item, ali)).status, 403);
  const c = await call('POST', '/products', item, admin);
  assert.equal(c.status, 201);
  assert.equal(c.body.id, 9);
  assert.equal((await call('PATCH', '/products/9', { price: 5 }, admin)).body.price, 5);
  assert.equal((await call('PUT', '/products/9', { name: 'x' }, admin)).status, 400);
  await call('POST', '/cart', { productId: 9 }, ali);
  assert.equal((await call('DELETE', '/products/9', undefined, admin)).status, 204);
  assert.equal((await call('GET', '/cart', undefined, ali)).body.items.length, 0);
  assert.equal((await call('GET', '/products/9')).status, 404);
});

test('data survives a server restart (persistence)', async () => {
  await stop();
  await start(); // new server, same data folder
  const orders = await call('GET', '/orders', undefined, ali); // login session was saved too
  assert.equal(orders.status, 200);
  assert.equal(orders.body[0].orderNo, 'ORD-000001');
  assert.equal((await call('GET', '/reviews')).body.length, 3);
  const files = await fs.readdir(dir);
  for (const f of ['users.json', 'orders.json', 'products.json', 'reviews.json', 'sessions.json']) {
    assert.ok(files.includes(f), `${f} should exist`);
  }
});
