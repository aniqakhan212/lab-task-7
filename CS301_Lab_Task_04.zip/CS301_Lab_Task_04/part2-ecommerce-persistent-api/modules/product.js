// Product module - CRUD.  Anyone can read; only an admin can create/update/delete.
const { HttpError, send, noContent, readBody, parseId, nextId, rules, validate } = require('../utils');
const auth = require('../auth');

const fields = {
  name: rules.text, price: rules.price, icon: rules.text,
  tag: rules.text, rating: rules.stars, colors: rules.colors
};
const DEFAULT_COLORS = ['#e0e7ff', '#c7d2fe'];

// READ (all) - filters: ?tag=Audio  ?q=watch  ?sort=price_asc | price_desc
async function getAll(ctx, req, res, url) {
  let items = await ctx.db.products.list();
  const tag = url.searchParams.get('tag');
  const q = url.searchParams.get('q');
  const sort = url.searchParams.get('sort');
  if (tag) items = items.filter((p) => p.tag.toLowerCase() === tag.toLowerCase());
  if (q) items = items.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));
  if (sort === 'price_asc') items = [...items].sort((a, b) => a.price - b.price);
  else if (sort === 'price_desc') items = [...items].sort((a, b) => b.price - a.price);
  else if (sort) throw new HttpError(400, 'sort must be price_asc or price_desc');
  send(res, 200, items);
}

// READ (one)
async function getOne(ctx, req, res, id) {
  const product = (await ctx.db.products.list()).find((p) => p.id === id);
  if (!product) throw new HttpError(404, 'Product not found');
  send(res, 200, product);
}

// CREATE (admin)
async function create(ctx, req, res) {
  auth.requireAdmin(await auth.requireUser(ctx, req));
  const data = validate(await readBody(req), fields, false, ['colors']);
  const product = await ctx.db.products.edit((products) => {
    const created = { id: nextId(products), colors: DEFAULT_COLORS, ...data };
    products.push(created);
    return { changed: true, value: created };
  });
  send(res, 201, product);
}

// UPDATE (admin) - PUT = all fields, PATCH = some fields
async function update(ctx, req, res, id) {
  auth.requireAdmin(await auth.requireUser(ctx, req));
  const data = validate(await readBody(req), fields, req.method === 'PATCH', ['colors']);
  const product = await ctx.db.products.edit((products) => {
    const found = products.find((p) => p.id === id);
    if (!found) throw new HttpError(404, 'Product not found');
    Object.assign(found, data);
    return { changed: true, value: { ...found } };
  });
  send(res, 200, product);
}

// DELETE (admin) - also removes the product from every cart
async function remove(ctx, req, res, id) {
  auth.requireAdmin(await auth.requireUser(ctx, req));
  await ctx.db.products.edit((products) => {
    const index = products.findIndex((p) => p.id === id);
    if (index < 0) throw new HttpError(404, 'Product not found');
    products.splice(index, 1);
    return { changed: true, value: null };
  });
  await ctx.db.carts.edit((carts) => {
    for (const cart of carts) cart.items = cart.items.filter((i) => i.productId !== id);
    return { changed: true, value: null };
  });
  noContent(res);
}

async function handle(ctx, req, res, parts, url) {
  if (parts.length > 1) throw new HttpError(404, 'Route not found');
  if (parts.length === 0) {
    if (req.method === 'GET') return getAll(ctx, req, res, url);
    if (req.method === 'POST') return create(ctx, req, res);
  } else {
    const id = parseId(parts[0]);
    if (req.method === 'GET') return getOne(ctx, req, res, id);
    if (req.method === 'PUT' || req.method === 'PATCH') return update(ctx, req, res, id);
    if (req.method === 'DELETE') return remove(ctx, req, res, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
