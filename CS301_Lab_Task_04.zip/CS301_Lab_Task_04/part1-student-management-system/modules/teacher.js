// Teacher module - CRUD
const db = require('../db');
const { HttpError, send, readBody, rules, validate, filterBy } = require('../utils');

const store = db.teachers;
const fields = { name: rules.text, subject: rules.text };

const findIndex = (id) => {
  const index = store.items.findIndex((t) => t.id === id);
  if (index < 0) throw new HttpError(404, 'Teacher not found');
  return index;
};

// CREATE
async function create(req, res) {
  const teacher = { id: store.nextId++, ...validate(await readBody(req), fields) };
  store.items.push(teacher);
  send(res, 201, teacher);
}

// READ (all, with optional ?subject=Networks filter)
function getAll(req, res, url) {
  send(res, 200, filterBy(store.items, url, ['name', 'subject']));
}

// READ (one)
function getOne(req, res, id) {
  send(res, 200, store.items[findIndex(id)]);
}

// UPDATE (PUT = all fields, PATCH = some fields)
async function update(req, res, id) {
  const index = findIndex(id);
  const data = validate(await readBody(req), fields, req.method === 'PATCH');
  store.items[index] = { ...store.items[index], ...data };
  send(res, 200, store.items[index]);
}

// DELETE (also removes attendance and marks recorded by this teacher)
function remove(req, res, id) {
  store.items.splice(findIndex(id), 1);
  db.attendance.items = db.attendance.items.filter((a) => a.teacherId !== id);
  db.marks.items = db.marks.items.filter((m) => m.teacherId !== id);
  res.writeHead(204);
  res.end();
}

async function handle(req, res, id, url) {
  if (id === null) {
    if (req.method === 'GET') return getAll(req, res, url);
    if (req.method === 'POST') return create(req, res);
  } else {
    if (req.method === 'GET') return getOne(req, res, id);
    if (req.method === 'PUT' || req.method === 'PATCH') return update(req, res, id);
    if (req.method === 'DELETE') return remove(req, res, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
