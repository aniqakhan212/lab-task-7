// One persistent JSON file per collection, inside the data folder.
const path = require('node:path');
const { createStore } = require('./store.js');
const seed = require('./seed.js');

function createDb(dir) {
  const file = (name) => path.join(dir, `${name}.json`);
  return {
    products: createStore(file('products'), seed.products),
    reviews:  createStore(file('reviews'), seed.reviews),
    users:    createStore(file('users')),
    sessions: createStore(file('sessions')),
    carts:    createStore(file('carts')),   // [{ userId, items: [{ productId, qty }] }]
    orders:   createStore(file('orders'))
  };
}

module.exports = { createDb };
