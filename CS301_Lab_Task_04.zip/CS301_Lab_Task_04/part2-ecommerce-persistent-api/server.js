// Start:  node server.js     (port 3005 or $PORT; data in ./data or $DATA_DIR)
// Make an admin:  ADMIN_EMAIL=admin@shop.com node server.js   then sign up with that email.
const { createApp } = require('./app.js');
const port = Number(process.env.PORT || 3005);
createApp().listen(port, () => {
  console.log(`ShopEasy API (persistent): http://localhost:${port}`);
  console.log('Routes: /auth  /products  /cart  /reviews  /orders');
});
