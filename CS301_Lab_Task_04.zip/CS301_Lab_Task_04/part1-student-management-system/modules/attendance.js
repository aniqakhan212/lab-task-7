// Attendance module - CRUD
const db = require('../db');
const { HttpError, send, readBody, rules, validate, filterBy, requireRefs } = require('../utils');

const store = db.attendance;
const fields = {
  studentId: rules.id,
  teacherId: rules.id,
  date: rules.date,
  status: rules.oneOf(['present', 'absent', 'late', 'leave'])
};

const findIndex = (id) => {
  const index = store.items.findIndex((a) => a.id === id);
  if (index < 0) throw new HttpError(404, 'Attendance record not found');
  return index;
};

// CREATE
async function create(req, res) {
  const data = validate(await readBody(req), fields);
  requireRefs(data);
  const record = { id: store.nextId++, ...data };
  store.items.push(record);
  send(res, 201, record);
}

// READ (all, with filters like ?studentId=1&status=absent&date=2026-10-24)
function getAll(req, res, url) {
  send(res, 200, filterBy(store.items, url, Object.keys(fields)));
}

// READ (one)
function getOne(req, res, id) {
  send(res, 200, store.items[findIndex(id)]);
}

// UPDATE (PUT = all fields, PATCH = some fields)
async function update(req, res, id) {
  const index = findIndex(id);
  const data = validate(await readBody(req), fields, req.method === 'PATCH');
  requireRefs(data);
  store.items[index] = { ...store.items[index], ...data };
  send(res, 200, store.items[index]);
}

// DELETE
function remove(req, res, id) {
  store.items.splice(findIndex(id), 1);
  res.writeHead(204);
  res.end();
}

async function handle(req, res, id, url) {
  if (id === null) {
    if (req.method === 'GET') return getAll(req, res, url);
    if (req.method === 'POST') return create(req, res);
  } else {
    if (req.method === 'GET') return getOne(req, res, id);
    if (req.method === 'PUT' || req.method === 'PATCH') return update(req, res, id);
    if (req.method === 'DELETE') return remove(req, res, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
