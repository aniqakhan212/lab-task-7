// Persistent storage: each collection is saved as a JSON file using fs/promises.
// Based on the Week 7 teaching pack (06-student-api/02-persistent-api/store.js).
// - Writes are queued so two requests never overwrite each other.
// - Data is written to a temp file first, then renamed (a crash can't corrupt the file).
const fs = require('node:fs/promises');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

function createStore(file, seed = []) {
  let writeQueue = Promise.resolve();

  async function load() {
    try { return JSON.parse(await fs.readFile(file, 'utf8')); }
    catch (error) {
      if (error.code === 'ENOENT') return structuredClone(seed); // first run: start from seed data
      throw error;
    }
  }

  // Read every record (waits for pending writes first).
  async function list() {
    await writeQueue;
    return load();
  }

  // Change the data safely. `change(items)` edits the array and returns
  // { changed: true/false, value: whatever the caller needs back }.
  function edit(change) {
    const operation = writeQueue.then(async () => {
      const items = await load();
      const result = change(items);
      if (result.changed) {
        await fs.mkdir(path.dirname(file), { recursive: true });
        const temp = `${file}.${randomUUID()}.tmp`;
        try {
          await fs.writeFile(temp, JSON.stringify(items, null, 2), 'utf8');
          await fs.rename(temp, file);
        } catch (error) {
          await fs.rm(temp, { force: true }).catch(() => {});
          throw error;
        }
      }
      return result.value;
    });
    writeQueue = operation.then(() => undefined, () => undefined);
    return operation;
  }

  return { list, edit };
}

module.exports = { createStore };
