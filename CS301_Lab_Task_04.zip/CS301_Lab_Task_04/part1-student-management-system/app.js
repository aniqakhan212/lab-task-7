// Router: picks the right module from the URL (/students, /teachers, /attendance, /marks).
const http = require('node:http');
const { HttpError, send } = require('./utils');

const routes = {
  students:   require('./modules/student.js'),
  teachers:   require('./modules/teacher.js'),
  attendance: require('./modules/attendance.js'),
  marks:      require('./modules/marks.js')
};

function createApp() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const parts = url.pathname.split('/').filter(Boolean); // e.g. ['students', '3']

      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { status: 'ok' });

      const module = routes[parts[0]];
      if (!module || parts.length > 2) throw new HttpError(404, 'Route not found');

      let id = null;
      if (parts.length === 2) {
        if (!/^[1-9]\d*$/.test(parts[1])) throw new HttpError(400, 'ID must be a positive integer');
        id = Number(parts[1]);
      }
      await module.handle(req, res, id, url);
    } catch (error) {
      if (res.headersSent) { res.destroy(error); return; }
      if (!(error instanceof HttpError)) console.error('[unexpected]', error);
      send(res, error instanceof HttpError ? error.status : 500,
        { error: error instanceof HttpError ? error.message : 'Internal server error' });
    }
  });
}

module.exports = { createApp };
