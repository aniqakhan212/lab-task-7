// Start the server:  node server.js   (default port 3004, or set PORT)
const { createApp } = require('./app.js');
const port = Number(process.env.PORT || 3004);
createApp().listen(port, () => {
  console.log(`Student Management API (in-memory): http://localhost:${port}`);
  console.log('Modules: /students  /teachers  /attendance  /marks');
});
