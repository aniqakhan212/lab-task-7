# CS301 Lab Task #04

Both parts use only Node.js built-in modules (Node 20+). No `npm install` needed.

## Part 1 - Student Management System (in-memory)
```
cd part1-student-management-system
node server.js            # http://localhost:3004
```
Modules (each has its own file in `modules/`): Student, Teacher, Attendance, Marks - full CRUD.

| Module | Routes |
|---|---|
| /students | GET, POST, GET/PUT/PATCH/DELETE `/students/:id` |
| /teachers | same |
| /attendance | same (fields: studentId, teacherId, date, status) |
| /marks | same (fields: studentId, teacherId, subject, score 0-100) |

Data is kept in memory and is lost when the server stops.

## Part 2 - ShopEasy e-commerce API (persistent, Lab 3 store.html)
```
cd part2-ecommerce-persistent-api
node server.js            # http://localhost:3005
npm test                  # 7 integration tests
```
Data is saved as JSON files in `data/` (created automatically; products and reviews start from the store.html seed data).
To get an admin account: `ADMIN_EMAIL=admin@shop.com node server.js`, then sign up with that email.

| Area | Endpoints | Access |
|---|---|---|
| Auth | POST `/auth/signup`, POST `/auth/login`, POST `/auth/logout`, GET `/auth/me` | public / token |
| Products | GET `/products` (`?tag=` `?q=` `?sort=price_asc\|price_desc`), GET `/products/:id` | public |
| | POST `/products`, PUT/PATCH/DELETE `/products/:id` | admin |
| Cart | GET `/cart`, POST `/cart` `{productId, qty}`, PUT/PATCH `/cart/:productId` `{qty}`, DELETE `/cart/:productId`, DELETE `/cart` | logged in |
| Reviews | GET `/reviews`, GET `/reviews/:id`, POST `/reviews` | public |
| | PATCH/PUT/DELETE `/reviews/:id` | author or admin |
| Orders (checkout) | POST `/orders` `{shipping:{name,address,city,phone}, payment:"cod"\|"card"}`, GET `/orders`, GET `/orders/:id`, PATCH `/orders/:id` `{status}` | logged in |

Send the login token as: `Authorization: Bearer <token>`.

Example:
```
curl -X POST localhost:3005/auth/signup -H "Content-Type: application/json" -d '{"name":"Ali","email":"ali@test.com","password":"secret1"}'
curl -X POST localhost:3005/cart -H "Content-Type: application/json" -H "Authorization: Bearer TOKEN" -d '{"productId":1,"qty":2}'
```
