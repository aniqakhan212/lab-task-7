// Shared helpers used by every module.
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function send(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(value));
}

function noContent(res) {
  res.writeHead(204);
  res.end();
}

async function readBody(req) {
  if (!String(req.headers['content-type'] || '').toLowerCase().includes('application/json')) {
    throw new HttpError(415, 'Content-Type must be application/json');
  }
  let raw = '';
  for await (const chunk of req) {
    raw += chunk.toString('utf8');
    if (Buffer.byteLength(raw) > 65536) throw new HttpError(413, 'Request body too large');
  }
  try { return JSON.parse(raw); }
  catch { throw new HttpError(400, 'Malformed JSON'); }
}

function parseId(text, label = 'ID') {
  if (!/^[1-9]\d*$/.test(text) || !Number.isSafeInteger(Number(text))) {
    throw new HttpError(400, `${label} must be a positive integer`);
  }
  return Number(text);
}

const nextId = (items) => items.reduce((max, item) => Math.max(max, item.id), 0) + 1;
const round2 = (n) => Math.round(n * 100) / 100;

// ---- Field rules: each returns the clean value or throws a 400 error ----
const rules = {
  text(v, key) {
    if (typeof v !== 'string' || !v.trim()) throw new HttpError(400, `${key} must be a non-empty string`);
    return v.trim();
  },
  email(v, key) {
    const email = rules.text(v, key).toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, `${key} must be a valid email`);
    return email;
  },
  password(v, key) {
    if (typeof v !== 'string' || v.length < 6) throw new HttpError(400, `${key} must be at least 6 characters`);
    return v;
  },
  phone(v, key) {
    const phone = rules.text(v, key);
    if (!/^[0-9+()\s-]{7,20}$/.test(phone)) throw new HttpError(400, `${key} must be a valid phone number`);
    return phone;
  },
  price(v, key) {
    if (typeof v !== 'number' || !Number.isFinite(v) || v <= 0 || v > 1000000 ||
        Math.abs(Math.round(v * 100) - v * 100) > 1e-6) {
      throw new HttpError(400, `${key} must be a positive number with at most 2 decimals`);
    }
    return v;
  },
  stars(v, key) {
    if (!Number.isInteger(v) || v < 1 || v > 5) throw new HttpError(400, `${key} must be a whole number from 1 to 5`);
    return v;
  },
  qty(v, key) {
    if (!Number.isInteger(v) || v < 1 || v > 99) throw new HttpError(400, `${key} must be a whole number from 1 to 99`);
    return v;
  },
  id(v, key) {
    if (!Number.isSafeInteger(v) || v < 1) throw new HttpError(400, `${key} must be a positive integer`);
    return v;
  },
  colors(v, key) {
    if (!Array.isArray(v) || v.length !== 2 || !v.every((c) => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c))) {
      throw new HttpError(400, `${key} must be two hex colors like ["#e0e7ff","#c7d2fe"]`);
    }
    return v;
  },
  oneOf: (list) => (v, key) => {
    if (!list.includes(v)) throw new HttpError(400, `${key} must be one of: ${list.join(', ')}`);
    return v;
  }
};

// Check a request body against a module's fields.
//  partial  = true for PATCH (only the fields that were sent are checked)
//  optional = field names that may be left out when creating
function validate(body, fields, partial = false, optional = []) {
  if (!body || Array.isArray(body) || typeof body !== 'object') {
    throw new HttpError(400, 'A JSON object is required');
  }
  const keys = Object.keys(body);
  const unknown = keys.filter((key) => !(key in fields));
  if (unknown.length) throw new HttpError(400, `Unknown field(s): ${unknown.join(', ')}`);
  if (partial && keys.length === 0) throw new HttpError(400, 'Give at least one field');
  const clean = {};
  for (const key of partial ? keys : Object.keys(fields)) {
    if (!partial && optional.includes(key) && body[key] === undefined) continue;
    clean[key] = fields[key](body[key], key);
  }
  return clean;
}

module.exports = { HttpError, send, noContent, readBody, parseId, nextId, round2, rules, validate };
