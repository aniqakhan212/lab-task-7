// Shared helpers used by every module.
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function send(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(value));
}

async function readBody(req) {
  if (!String(req.headers['content-type'] || '').toLowerCase().includes('application/json')) {
    throw new HttpError(415, 'Content-Type must be application/json');
  }
  let raw = '';
  for await (const chunk of req) {
    raw += chunk.toString('utf8');
    if (Buffer.byteLength(raw) > 65536) throw new HttpError(413, 'Request body too large');
  }
  try { return JSON.parse(raw); }
  catch { throw new HttpError(400, 'Malformed JSON'); }
}

// ---- Field rules: each returns the clean value or throws a 400 error ----
const rules = {
  text(v, key) {
    if (typeof v !== 'string' || !v.trim()) throw new HttpError(400, `${key} must be a non-empty string`);
    return v.trim();
  },
  id(v, key) {
    if (!Number.isSafeInteger(v) || v < 1) throw new HttpError(400, `${key} must be a positive integer`);
    return v;
  },
  date(v, key) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(Date.parse(v))) {
      throw new HttpError(400, `${key} must be a date like 2026-10-25`);
    }
    return v;
  },
  score(v, key) {
    if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 100) {
      throw new HttpError(400, `${key} must be a number between 0 and 100`);
    }
    return v;
  },
  oneOf: (list) => (v, key) => {
    if (!list.includes(v)) throw new HttpError(400, `${key} must be one of: ${list.join(', ')}`);
    return v;
  }
};

// Check a request body against a module's fields. partial = true is for PATCH.
function validate(body, fields, partial = false) {
  if (!body || Array.isArray(body) || typeof body !== 'object') {
    throw new HttpError(400, 'A JSON object is required');
  }
  const keys = Object.keys(body);
  const unknown = keys.filter((key) => !(key in fields));
  if (unknown.length) throw new HttpError(400, `Unknown field(s): ${unknown.join(', ')}`);
  if (partial && keys.length === 0) throw new HttpError(400, 'Give at least one field');
  const clean = {};
  for (const key of partial ? keys : Object.keys(fields)) clean[key] = fields[key](body[key], key);
  return clean;
}

// Apply query-string filters such as /marks?studentId=1
function filterBy(items, url, allowed) {
  let result = items;
  for (const [key, value] of url.searchParams) {
    if (!allowed.includes(key)) throw new HttpError(400, `Cannot filter by ${key}`);
    result = result.filter((item) => String(item[key]) === value);
  }
  return result;
}

// Make sure studentId / teacherId really exist.
function requireRefs(data) {
  const db = require('./db');
  if ('studentId' in data && !db.exists('students', data.studentId)) {
    throw new HttpError(400, `studentId ${data.studentId} does not exist`);
  }
  if ('teacherId' in data && !db.exists('teachers', data.teacherId)) {
    throw new HttpError(400, `teacherId ${data.teacherId} does not exist`);
  }
}

module.exports = { HttpError, send, readBody, rules, validate, filterBy, requireRefs };
