// Password hashing + login sessions (bearer tokens saved in sessions.json).
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { HttpError } = require('./utils.js');

const scrypt = promisify(crypto.scrypt);
const SESSION_MS = 7 * 24 * 60 * 60 * 1000; // sessions last 7 days
const sha256 = (text) => crypto.createHash('sha256').update(text).digest('hex');

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, 64);
  return `${salt}:${key.toString('hex')}`;
}

async function checkPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const key = await scrypt(password, salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return key.length === expected.length && crypto.timingSafeEqual(key, expected);
}

const publicUser = ({ passwordHash, ...rest }) => rest; // never send the hash back

async function createSession(ctx, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  await ctx.db.sessions.edit((sessions) => {
    const now = Date.now();
    for (let i = sessions.length - 1; i >= 0; i--) {
      if (now - sessions[i].createdAt > SESSION_MS) sessions.splice(i, 1); // drop expired
    }
    sessions.push({ tokenHash: sha256(token), userId, createdAt: now }); // only the hash is stored
    return { changed: true, value: null };
  });
  return token;
}

function tokenOf(req) {
  const match = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  return match ? match[1] : null;
}

async function destroySession(ctx, req) {
  const hash = sha256(tokenOf(req) || '');
  await ctx.db.sessions.edit((sessions) => {
    const index = sessions.findIndex((s) => s.tokenHash === hash);
    if (index >= 0) sessions.splice(index, 1);
    return { changed: index >= 0, value: null };
  });
}

// The logged-in user, or null (for routes where login is optional).
async function currentUser(ctx, req) {
  const token = tokenOf(req);
  if (!token) return null;
  const hash = sha256(token);
  const session = (await ctx.db.sessions.list())
    .find((s) => s.tokenHash === hash && Date.now() - s.createdAt <= SESSION_MS);
  if (!session) return null;
  return (await ctx.db.users.list()).find((u) => u.id === session.userId) || null;
}

async function requireUser(ctx, req) {
  const user = await currentUser(ctx, req);
  if (!user) throw new HttpError(401, 'Login required: send header Authorization: Bearer <token>');
  return user;
}

function requireAdmin(user) {
  if (user.role !== 'admin') throw new HttpError(403, 'Admin only');
}

module.exports = {
  hashPassword, checkPassword, publicUser, createSession, destroySession,
  currentUser, requireUser, requireAdmin
};
