// In-memory "database": one list + id counter per module. Lost when the server stops.
const db = {
  students:   { items: [], nextId: 1 },
  teachers:   { items: [], nextId: 1 },
  attendance: { items: [], nextId: 1 },
  marks:      { items: [], nextId: 1 }
};

// True if a record with this id exists in the given module (used for foreign keys).
db.exists = (moduleName, id) => db[moduleName].items.some((item) => item.id === id);

module.exports = db;
