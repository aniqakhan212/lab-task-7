// Starting data (same products and reviews as the Lab 3 store.html page).
const products = [
  { id: 1, name: 'Wireless Headphones', price: 59.99, icon: '🎧', tag: 'Audio',    rating: 5, colors: ['#e0e7ff', '#c7d2fe'] },
  { id: 2, name: 'Smart Watch',         price: 89.5,  icon: '⌚', tag: 'Wearable', rating: 4, colors: ['#fce7f3', '#fbcfe8'] },
  { id: 3, name: 'Backpack',            price: 39,    icon: '🎒', tag: 'Bags',     rating: 4, colors: ['#dcfce7', '#bbf7d0'] },
  { id: 4, name: 'Sunglasses',          price: 24.99, icon: '🕶️', tag: 'Style',    rating: 5, colors: ['#fef3c7', '#fde68a'] },
  { id: 5, name: 'Running Shoes',       price: 74,    icon: '👟', tag: 'Sport',    rating: 5, colors: ['#ffe4e6', '#fecdd3'] },
  { id: 6, name: 'Coffee Mug',          price: 12.5,  icon: '☕', tag: 'Home',     rating: 4, colors: ['#ede9fe', '#ddd6fe'] },
  { id: 7, name: 'Desk Lamp',           price: 29.99, icon: '💡', tag: 'Home',     rating: 4, colors: ['#fef9c3', '#fef08a'] },
  { id: 8, name: 'Bluetooth Speaker',   price: 45,    icon: '🔊', tag: 'Audio',    rating: 5, colors: ['#cffafe', '#a5f3fc'] }
];

const reviews = [
  { id: 1, userId: null, name: 'Sara',  stars: 5, text: 'Fast delivery and great quality. Loved the headphones!', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 2, userId: null, name: 'Ahmed', stars: 4, text: 'Good prices and easy checkout.',                         createdAt: '2026-01-02T00:00:00.000Z' }
];

module.exports = { products, reviews };
