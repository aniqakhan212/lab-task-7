// Order module (login required) - this is the checkout.
//   POST /orders        place an order from your cart
//                       { "shipping": {"name","address","city","phone"}, "payment": "cod" | "card" }
//   GET /orders         your orders (admin sees all)
//   GET /orders/:id     one order (yours, or any if admin)
//   PATCH /orders/:id   { "status": "..." }  customers may only cancel a "placed" order; admin can set any status
const { HttpError, send, readBody, parseId, nextId, rules, validate } = require('../utils');
const auth = require('../auth');
const { buildView } = require('./cart');

const STATUSES = ['placed', 'shipped', 'delivered', 'cancelled'];
const shipping = (v, key) => {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new HttpError(400, `${key} must be an object`);
  return validate(v, { name: rules.text, address: rules.text, city: rules.text, phone: rules.phone });
};

async function place(ctx, req, res, user) {
  const data = validate(await readBody(req),
    { shipping, payment: rules.oneOf(['cod', 'card']) }, false, ['payment']);
  const cart = await buildView(ctx, user.id);
  if (!cart.items.length) throw new HttpError(400, 'Your cart is empty');

  const order = await ctx.db.orders.edit((orders) => {
    const id = nextId(orders);
    const created = {
      id,
      orderNo: `ORD-${String(id).padStart(6, '0')}`,
      userId: user.id,
      items: cart.items.map(({ productId, name, price, qty, lineTotal }) => ({ productId, name, price, qty, lineTotal })),
      total: cart.total,
      shipping: data.shipping,
      payment: data.payment || 'cod',
      status: 'placed',
      createdAt: new Date().toISOString()
    };
    orders.push(created);
    return { changed: true, value: created };
  });

  // Order saved -> empty the cart.
  await ctx.db.carts.edit((carts) => {
    const mine = carts.find((c) => c.userId === user.id);
    if (mine) mine.items = [];
    return { changed: Boolean(mine), value: null };
  });
  send(res, 201, order);
}

async function getAll(ctx, res, user, url) {
  let orders = await ctx.db.orders.list();
  if (user.role !== 'admin') orders = orders.filter((o) => o.userId === user.id);
  const status = url.searchParams.get('status');
  if (status) orders = orders.filter((o) => o.status === status);
  send(res, 200, orders);
}

async function findFor(ctx, user, id) {
  const order = (await ctx.db.orders.list()).find((o) => o.id === id);
  // Hide other people's orders completely (404, not 403).
  if (!order || (user.role !== 'admin' && order.userId !== user.id)) throw new HttpError(404, 'Order not found');
  return order;
}

async function setStatus(ctx, req, res, user, id) {
  const { status } = validate(await readBody(req), { status: rules.oneOf(STATUSES) });
  const order = await ctx.db.orders.edit((orders) => {
    const found = orders.find((o) => o.id === id && (user.role === 'admin' || o.userId === user.id));
    if (!found) throw new HttpError(404, 'Order not found');
    if (user.role !== 'admin') {
      if (status !== 'cancelled') throw new HttpError(403, 'Customers can only cancel an order');
      if (found.status !== 'placed') throw new HttpError(409, 'Only a placed order can be cancelled');
    }
    found.status = status;
    return { changed: true, value: { ...found } };
  });
  send(res, 200, order);
}

async function handle(ctx, req, res, parts, url) {
  if (parts.length > 1) throw new HttpError(404, 'Route not found');
  const user = await auth.requireUser(ctx, req);
  if (parts.length === 0) {
    if (req.method === 'GET') return getAll(ctx, res, user, url);
    if (req.method === 'POST') return place(ctx, req, res, user);
  } else {
    const id = parseId(parts[0]);
    if (req.method === 'GET') return send(res, 200, await findFor(ctx, user, id));
    if (req.method === 'PATCH') return setStatus(ctx, req, res, user, id);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle };
