// Cart module (login required). Each user has one cart saved in carts.json.
//   GET /cart                   view cart with totals
//   POST /cart                  add item   { "productId": 1, "qty": 2 }  (qty optional, default 1)
//   PUT/PATCH /cart/:productId  set quantity { "qty": 3 }
//   DELETE /cart/:productId     remove one item
//   DELETE /cart                empty the cart
const { HttpError, send, noContent, readBody, parseId, round2, rules, validate } = require('../utils');
const auth = require('../auth');

// Build the cart the client sees, using live product prices.
async function buildView(ctx, userId) {
  const [carts, products] = await Promise.all([ctx.db.carts.list(), ctx.db.products.list()]);
  const mine = carts.find((c) => c.userId === userId);
  const items = (mine ? mine.items : []).flatMap((item) => {
    const p = products.find((x) => x.id === item.productId);
    if (!p) return [];
    return [{ productId: p.id, name: p.name, icon: p.icon, price: p.price, qty: item.qty, lineTotal: round2(p.price * item.qty) }];
  });
  return { items, count: items.reduce((s, i) => s + i.qty, 0), total: round2(items.reduce((s, i) => s + i.lineTotal, 0)) };
}

// Run a change on this user's cart (creates the cart on first use).
function editCart(ctx, userId, change) {
  return ctx.db.carts.edit((carts) => {
    let cart = carts.find((c) => c.userId === userId);
    if (!cart) { cart = { userId, items: [] }; carts.push(cart); }
    return { changed: true, value: change(cart) };
  });
}

async function add(ctx, req, res, user) {
  const data = validate(await readBody(req), { productId: rules.id, qty: rules.qty }, false, ['qty']);
  const qty = data.qty ?? 1;
  const product = (await ctx.db.products.list()).find((p) => p.id === data.productId);
  if (!product) throw new HttpError(404, 'Product not found');
  await editCart(ctx, user.id, (cart) => {
    const item = cart.items.find((i) => i.productId === data.productId);
    if (item) {
      if (item.qty + qty > 99) throw new HttpError(400, 'Maximum 99 of one product');
      item.qty += qty;
    } else cart.items.push({ productId: data.productId, qty });
  });
  send(res, 201, await buildView(ctx, user.id));
}

async function setQty(ctx, req, res, user, productId) {
  const { qty } = validate(await readBody(req), { qty: rules.qty });
  await editCart(ctx, user.id, (cart) => {
    const item = cart.items.find((i) => i.productId === productId);
    if (!item) throw new HttpError(404, 'That product is not in your cart');
    item.qty = qty;
  });
  send(res, 200, await buildView(ctx, user.id));
}

async function removeItem(ctx, res, user, productId) {
  await editCart(ctx, user.id, (cart) => {
    const index = cart.items.findIndex((i) => i.productId === productId);
    if (index < 0) throw new HttpError(404, 'That product is not in your cart');
    cart.items.splice(index, 1);
  });
  noContent(res);
}

async function clear(ctx, res, user) {
  await editCart(ctx, user.id, (cart) => { cart.items = []; });
  noContent(res);
}

async function handle(ctx, req, res, parts) {
  if (parts.length > 1) throw new HttpError(404, 'Route not found');
  const user = await auth.requireUser(ctx, req);
  if (parts.length === 0) {
    if (req.method === 'GET') return send(res, 200, await buildView(ctx, user.id));
    if (req.method === 'POST') return add(ctx, req, res, user);
    if (req.method === 'DELETE') return clear(ctx, res, user);
  } else {
    const productId = parseId(parts[0], 'Product ID');
    if (req.method === 'PUT' || req.method === 'PATCH') return setQty(ctx, req, res, user, productId);
    if (req.method === 'DELETE') return removeItem(ctx, res, user, productId);
  }
  throw new HttpError(405, 'Method not allowed');
}

module.exports = { handle, buildView };
